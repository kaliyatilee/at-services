<footer class="footer position-absolute bottom-footer py-2 w-100 z-index-1">
    <div class="container">
        <div class="row align-items-center justify-content-lg-between">
            <div class="col-12 col-md-6 my-auto">
                <div class="copyright text-center text-sm text-muted text-lg-start">
                    © <script>
                        document.write(new Date().getFullYear())

                    </script>
                    Developed by
                    <a href="https://www.leonapplications.com" class="font-weight-bold" target="_blank">Leon Applications</a>
                </div>
            </div>
        </div>
    </div>
</footer>
